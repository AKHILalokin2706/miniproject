from django.contrib import admin

from .models import job

admin.site.register(job)